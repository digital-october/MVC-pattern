<?=$name?>
<pre>
<? print_r($authUser);?>
