<h2>Регистрация</h2>
<hr>
<form class="navbar-form navbar-left" role="Reg" action="/registration" method="post">
    <div class="form-group">
        Имя пользователя:
        <input type="text" class="form-control" name="name" placeholder="name">
        Пароль:
        <input type="password" class="form-control" name="password" placeholder="password">
        Email:
        <input type="text" class="form-control" name="email" placeholder="email">
        <input type="submit" class="btn btn-default">
    </div>
</form>


