<?

require __DIR__.'/../vendor/autoload.php';

include __DIR__.'/app.php';