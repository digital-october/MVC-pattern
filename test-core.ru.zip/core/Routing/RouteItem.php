<?

namespace Core\Routing;

use Core\Routing\Route\Item\RouteItemAbstract;

class RouteItem extends RouteItemAbstract
{
    public $version = 'first edition';

}