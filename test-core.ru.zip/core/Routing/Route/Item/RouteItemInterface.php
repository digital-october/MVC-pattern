<?php

namespace Core\Routing\Route\Item;

interface RouteItemInterface
{
    public function getUri();

}